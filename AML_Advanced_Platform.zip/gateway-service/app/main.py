
from fastapi import FastAPI
import requests

app = FastAPI()

SCREEN_URL="http://screening-service:8000/screen"
WATCH_URL="http://watchlist-service:8001/watchlist"

@app.post("/process")
def process(customer:dict):
    watch=requests.get(WATCH_URL).json()[0]
    resp=requests.post(SCREEN_URL,json={"customer":customer,"watchlist":watch})
    return resp.json()
