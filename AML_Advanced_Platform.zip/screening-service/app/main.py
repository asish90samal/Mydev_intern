
from fastapi import FastAPI
from app.engine import generate_features, predict_risk, decision_logic

app = FastAPI()

@app.post("/screen")
def screen(payload: dict):
    customer = payload["customer"]
    watchlist = payload["watchlist"]
    features = generate_features(customer, watchlist)
    prob = predict_risk(features)
    decision = decision_logic(prob)
    return {
        "true_match_probability": float(prob),
        "decision": decision
    }
