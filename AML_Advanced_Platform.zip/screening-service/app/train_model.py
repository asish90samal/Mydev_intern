
import numpy as np
from sklearn.linear_model import LogisticRegression
import joblib

X = np.array([
    [0.95,1,1,1,0.9],
    [0.90,0,0,1,0.9],
    [0.85,1,0,1,0.8],
    [0.40,0,0,0,0.3],
    [0.99,1,1,1,1.0],
    [0.70,0,0,0,0.6]
])
y = np.array([1,0,1,0,1,0])

model = LogisticRegression()
model.fit(X,y)
joblib.dump(model,"risk_model.pkl")
print("Model trained successfully")
