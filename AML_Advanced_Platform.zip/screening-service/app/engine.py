
from rapidfuzz import fuzz
import numpy as np
import joblib
import os

MODEL_PATH = os.path.join(os.path.dirname(__file__), "risk_model.pkl")
model = joblib.load(MODEL_PATH)

def normalize(x): 
    return x.lower().strip()

def name_similarity(a,b): 
    return fuzz.token_sort_ratio(a,b)/100.0

def generate_features(customer, watchlist):
    return np.array([[
        name_similarity(normalize(customer["name"]), normalize(watchlist["name"])),
        1.0 if customer["dob"]==watchlist["dob"] else 0.0,
        1.0 if customer["country"]==watchlist["country"] else 0.0,
        1.0 if customer["gender"]==watchlist["gender"] else 0.0,
        watchlist["severity"]
    ]])

def predict_risk(features):
    return model.predict_proba(features)[0][1]

def decision_logic(prob):
    if prob>0.8: 
        return "HIGH PRIORITY REVIEW"
    elif prob>0.4: 
        return "MEDIUM PRIORITY REVIEW"
    return "LOW PRIORITY"
