
from fastapi import FastAPI

app = FastAPI()

WATCHLIST=[
 {"name":"Muhammad Ali","dob":"1960-01-01","country":"Syria","gender":"Male","severity":0.9}
]

@app.get("/watchlist")
def get_watchlist():
    return WATCHLIST
